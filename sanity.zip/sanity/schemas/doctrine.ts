export default {
  name: 'doctrine',
  title: 'Doctrine',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string', validation: Rule => Rule.required().min(5) },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title', maxLength: 96 } },
    { name: 'summary', title: 'Summary', type: 'text', rows: 3 },
    { name: 'content', title: 'Content', type: 'array', of: [{ type: 'block' }] },
    { name: 'tags', title: 'Tags', type: 'array', of: [{ type: 'string' }] },
    { name: 'publishedAt', title: 'Published At', type: 'datetime' }
  ]
}
