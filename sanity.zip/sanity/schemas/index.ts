import doctrine from './doctrine'

export default [doctrine]
