import { defineConfig } from 'sanity'
import { deskTool } from 'sanity/desk'
import schemas from './schemas'

export default defineConfig({
  name: 'default',
  title: 'The Cosmology',
  projectId: 'your_project_id',
  dataset: 'production',
  plugins: [deskTool()],
  schema: {
    types: schemas,
  },
})
