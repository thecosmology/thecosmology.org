export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Welcome to The Cosmology</h1>
      <p>This site is under development. Stay tuned for doctrine, vision, and transformation.</p>
    </div>
  );
}
