export default function Home() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Welcome to The Cosmology</h1>
      <p>This is the beginning of a new understanding. Content coming soon.</p>
    </main>
  );
}
